/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package constantekaprekar;

import Secuencia.Kaprekar;
import java.util.Scanner;

/**
 *
 * @author JuanMa
 */
public class ConstanteKaprekar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner cin;
        cin = new Scanner(System.in);
        String Entrada = cin.nextLine();
        String resultado = Kaprekar.ComprobarEntrada(Entrada);
        System.out.println(resultado);
    }
    
}
