/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Secuencia;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author JuanMa
 */
public class Kaprekar {
    public static String ComprobarEntrada(String Entrada){
        int numero = 0;
        try{ numero = Integer.parseInt(Entrada); }
        catch(NumberFormatException ex){ return "Simbolos o letras ingresadas"; }
        if(Entrada.length() > 4){ return "Numero mayor a 4 digitos";}
        for(int i = Entrada.length(); i < 4; i++){
            Entrada = "0" + Entrada;
        }
        boolean NumerosIguales = true;
        char primerCaracter = Entrada.charAt(0);
        for (int i = 1; i < Entrada.length(); i++) {
            if (Entrada.charAt(i) != primerCaracter) {
                NumerosIguales = false;
                break;
            }
        }
        if(NumerosIguales == true){
            return "Todos los numeros ingresados son iguales";
        }
        return Secuencia(Entrada);
    }
    
    public static String Secuencia(String Entrada){
        if(Entrada.matches("6174")){
            return Entrada;
        }
        Integer[] NumeroMayor = {0,0,0,0};
        Integer[] NumeroMenor = {0,0,0,0};
        NumeroMenor[0] = Character.getNumericValue(Entrada.charAt(0));
        NumeroMenor[1] = Character.getNumericValue(Entrada.charAt(1));
        NumeroMenor[2] = Character.getNumericValue(Entrada.charAt(2));
        NumeroMenor[3] = Character.getNumericValue(Entrada.charAt(3));
        Arrays.sort(NumeroMenor);
        NumeroMayor[0] = NumeroMenor[3];
        NumeroMayor[1] = NumeroMenor[2];
        NumeroMayor[2] = NumeroMenor[1];
        NumeroMayor[3] = NumeroMenor[0];
        
        int mayor = (NumeroMayor[0] * 1000) + (NumeroMayor[1] * 100) + (NumeroMayor[2] * 10) + NumeroMayor[3];
        int menor = (NumeroMenor[0] * 1000) + (NumeroMenor[1] * 100) + (NumeroMenor[2] * 10) + NumeroMenor[3];
        String smenor = Integer.toString(menor);
        for(int i = smenor.length(); i < 4; i++){
            smenor = "0" + smenor;
        }
        String resultado = Integer.toString(mayor - menor);
        for(int i = resultado.length(); i < 4; i++){
            resultado = "0" + resultado;
        }
        System.out.println(mayor + " - " + smenor + " = " + resultado);
        return Secuencia(resultado);
    }
}
