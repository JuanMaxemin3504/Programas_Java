/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package juegogatoservidor;

/**
 *
 * @author faked
 */
import java.io.*;
import java.net.*;
import java.util.Random;

public class JuegoGatoServidor {
    private static final int PORT = 12345;

    public JuegoGatoServidor() {
        // Configuración del servidor
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Esperando conexión del cliente...");

            // Bucle principal para aceptar múltiples clientes
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Cliente conectado.");

                // Crear un nuevo hilo para manejar la conexión con el cliente
                new Thread(new ClienteHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Clase interna que maneja cada cliente en un hilo separado
    private class ClienteHandler implements Runnable {
        private Socket socket;
        private char[][] tablero;
        private DataOutputStream out;
        private DataInputStream in;

        public ClienteHandler(Socket socket) {
            this.socket = socket;
            this.tablero = new char[3][3]; // Inicializar el tablero
            inicializarTablero();
        }

        @Override
        public void run() {
            try {
                // Flujos de entrada y salida
                out = new DataOutputStream(socket.getOutputStream());
                in = new DataInputStream(socket.getInputStream());

                // Bucle para manejar el juego con el cliente
                while (true) {
                    // Leer movimiento del cliente
                    int x = in.readInt();
                    int y = in.readInt();
                    tablero[x][y] = 'X'; // Actualizar el tablero del servidor

                    // Verificar si el cliente ha ganado
                    if (verificarGanador()) {
                        out.writeUTF("Cliente ha ganado!");
                        break; // Salir del bucle si hay un ganador
                    } else if (esEmpate()) {
                        out.writeUTF("Empate.");
                        break; // Salir del bucle si hay un empate
                    } else {
                        // Movimiento aleatorio del servidor
                        hacerMovimientoAleatorio();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                // Cerrar conexiones al finalizar el juego
                try {
                    if (out != null) out.close();
                    if (in != null) in.close();
                    socket.close();
                    System.out.println("Cliente desconectado.");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void inicializarTablero() {
            // Inicializar el tablero
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    tablero[i][j] = ' ';
                }
            }
        }

        private void hacerMovimientoAleatorio() throws IOException {
            Random rand = new Random();
            int x, y;

            // Buscar un movimiento aleatorio válido
            do {
                x = rand.nextInt(3);
                y = rand.nextInt(3);
            } while (tablero[x][y] != ' ');

            tablero[x][y] = 'O'; // El servidor hace su movimiento
            out.writeInt(x);
            out.writeInt(y);
        }

        private boolean verificarGanador() {
            // Lógica de verificación de ganador
            for (int i = 0; i < 3; i++) {
                if (tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2] && tablero[i][0] != ' ')
                    return true;
                if (tablero[0][i] == tablero[1][i] && tablero[1][i] == tablero[2][i] && tablero[0][i] != ' ')
                    return true;
            }
            return (tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2] && tablero[0][0] != ' ')
                    || (tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0] && tablero[0][2] != ' ');
        }

        private boolean esEmpate() {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (tablero[i][j] == ' ')
                        return false;
            return true;
        }
    }

    public static void main(String[] args) {
        new JuegoGatoServidor();
    }
}

