/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Matrices.Matriz;
import java.awt.Graphics;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author faked
 */
public class Vistas extends JFrame {
     
    int Tx = 0;
    int Ty = 0;
    int Tz = 0;
    int Rx = 0;
    int Ry = 0;
    int Rz = 0;
    int Zx = 1;
    int Zy = 1;
    int Zz = 1;
    
     public Vistas(){ 
        super();
        config();
    }
    private void config() {
        setTitle("Interfas 4 programas");
        setSize(800, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
            //Traslacion
        JButton DesplazarX = new JButton("Desplazar X");
            DesplazarX.addActionListener ((e) -> TraslacionX() );
            
        JButton Desplazar_X = new JButton("Desplazar -X");
            Desplazar_X.addActionListener ((e) -> Traslacion_X() );
            
        JButton DesplazarY = new JButton("Desplzar Y");
            DesplazarY.addActionListener ((e) -> Traslacion_Y() );
            
        JButton Desplazar_Y = new JButton("Desplazar -Y");
            Desplazar_Y.addActionListener ((e) -> TraslacionY() );
            
        JButton DesplazarZ = new JButton("Desplzar Z");
            DesplazarZ.addActionListener ((e) -> TraslacionZ() );
            
        JButton Desplazar_Z = new JButton("Desplazar -Z");
            Desplazar_Z.addActionListener ((e) -> Traslacion_Z() );
            
            //Rotacion            
        JButton RotarX = new JButton("Rotar X");
            RotarX.addActionListener ((e) -> RotacionX() );
            
        JButton Rotar_X = new JButton("Rotar -X");
            Rotar_X.addActionListener ((e) -> Rotacion_X() );
            
        JButton RotarY = new JButton("Rotar Y");
            RotarY.addActionListener ((e) -> RotacionY() );
            
        JButton Rotar_Y = new JButton("Rotar -Y");
            Rotar_Y.addActionListener ((e) -> Rotacion_Y() );
            
        JButton RotarZ = new JButton("Rotar Z");
            RotarZ.addActionListener ((e) -> RotacionZ() );
            
        JButton Rotar_Z = new JButton("Rotar -Z");
            Rotar_Z.addActionListener ((e) -> Rotacion_Z() );
            
            //Zoom
        JButton ZoomOut = new JButton("Zoom Out");
            ZoomOut.addActionListener ((e) -> ZoomOut() );
            
        JButton ZoomIn = new JButton("Zoom In");
            ZoomIn.addActionListener ((e) -> ZoomIn() );
            
        JButton PosInicio = new JButton("Posicion Inicial");
            PosInicio.addActionListener( (e) -> DevolverInicio() );
        
        GroupLayout g1 = new GroupLayout (getContentPane()); 
        
        g1.setAutoCreateContainerGaps(true);
        g1.setAutoCreateGaps(true);
              
        g1.setHorizontalGroup
        (
            g1.createSequentialGroup()
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(DesplazarX)
                    .addComponent(Desplazar_X)
            )
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(DesplazarY)
                    .addComponent(Desplazar_Y)
            )     
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(DesplazarZ)
                    .addComponent(Desplazar_Z)
            )     
             //Rotar
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(RotarX)
                    .addComponent(Rotar_X)
                    .addComponent(PosInicio)
            )
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(RotarY)
                    .addComponent(Rotar_Y)
            )     
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(RotarZ)
                    .addComponent(Rotar_Z)
            )     
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(ZoomOut)
                    .addComponent(ZoomIn)
            )     
        );
        
        g1.setVerticalGroup
        (
            g1.createSequentialGroup()
            .addGap(550)
            .addGroup
            (
                g1.createParallelGroup()
                .addComponent(PosInicio)
            )
            .addGroup
            (
                g1.createParallelGroup()
                .addComponent(DesplazarX)
                .addComponent(DesplazarY)
                .addComponent(DesplazarZ)
                .addComponent(RotarX)
                .addComponent(RotarY)
                .addComponent(RotarZ)
                .addComponent(ZoomOut)
            )
            .addGroup
            (
                g1.createParallelGroup()
                .addComponent(Desplazar_X)
                .addComponent(Desplazar_Y)
                .addComponent(Desplazar_Z)
                .addComponent(Rotar_X)
                .addComponent(Rotar_Y)
                .addComponent(Rotar_Z)
                .addComponent(ZoomIn)
            )
        );
        setLayout(g1);
    }
    
    @Override
    public void paint(Graphics g) {
        Matriz.MatrizInicial();
        Matriz.CalcularMatriz(Tx, Ty, Tz, Rx, Ry, Rz, Zx, Zy, Zz);
        Matriz.CalcularVertices();
        super.paint(g);
        int centrado = 300;
        for(int i = 0; i < 15; i++){
             g.drawLine(Matrices.Matriz.ListaVertices.get(i)[0] + centrado,
                     Matrices.Matriz.ListaVertices.get(i)[1] + centrado,
                     Matrices.Matriz.ListaVertices.get(i + 1)[0] + centrado,
                     Matrices.Matriz.ListaVertices.get(i + 1)[1] + centrado);
        }
    }    
    
    private void TraslacionX(){
        Tx += 5;
        repaint();
    }
    
    private void Traslacion_X(){
        Tx -= 5;
        repaint();
    }
    private void TraslacionY(){
        Ty += 5;
        repaint();
    }
    
    private void Traslacion_Y(){
        Ty -= 5;
        repaint();
    }
    private void TraslacionZ(){
        Tz += 5;
        repaint();
    }
    
    private void Traslacion_Z(){
        Tz -= 5;
        repaint();
    }
    
    private void RotacionX(){
        Rx += 5;
        if(Rx == 360)
            Rx = 0;
        repaint();
    }
    private void Rotacion_X(){
        Rx -= 5;
        if(Rx < 0)
            Rx = 355;
        repaint();
    }
    private void RotacionY(){
        Ry += 5;
        if(Ry == 360)
            Ry = 0;
        repaint();
    }
    private void Rotacion_Y(){
        Ry -= 5;
        if(Ry < 0)
            Ry = 355;
        repaint();
    }
    private void RotacionZ(){
        Rz += 5;
        if(Rz == 360)
            Rz = 0;
        repaint();
    }
    private void Rotacion_Z(){
        Rz -= 5;
        if(Rz < 0)
            Rz = 355;
        repaint();
    }
    
    private void ZoomIn(){
        Zx ++;
        Zy ++;
        Zz ++;
        repaint();
    }
    
    private void ZoomOut(){
        if(Zx > 0){
            Zx --;
            Zy --;
            Zz --;
            repaint();
        }
    }
    
    private void DevolverInicio(){
        Tx = 0;
        Ty = 0;
        Tz = 0;
        Rx = 0;
        Ry = 0;
        Rz = 0;
        Zx = 1;
        Zy = 1;
        Zz = 1;
        repaint();
    }
}
