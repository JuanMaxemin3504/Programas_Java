/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Matrices;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author faked
 */
public class Matriz {
    
    private static List<double[][]> MatrizBase = new ArrayList<>();
    private static List<double[][]> ListaMatricesAuxiliar = new ArrayList<>();
    public static List<int[]> ListaVertices = new ArrayList<>();
    
    public static void MatrizInicial(){
        MatrizBase.clear();
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 100}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 100}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, -100}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, -100}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 100}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, -100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 100}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, -100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, -100}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, -100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 100}, {0, 0, 0, 1}});
        MatrizBase.add( new double[][] {{1, 0, 0, 0}, {0, 1, 0, -100}, {0, 0, 1, 0}, {0, 0, 0, 1}});
    }
    
    public static void CalcularMatriz(int TxV, int TyV, int TzV, int RxV, int RyV, int RzV, int ZxV, int ZyV, int ZzV) {

        double[][] Traslacion = new double[][] 
            {{1 , 0 , 0, TxV}, 
            { 0 , 1, 0, TyV},
            {0 , 0 , 1, TzV},
            { 0 , 0, 0, 1}};

        double[][] Zoom = new double[][]
            {{ZxV , 0 , 0, 0},
            { 0 , ZyV, 0, 0},
            {0 , 0 , ZzV, 0},
            { 0 , 0, 0, 1}};

        double[][] Rx = new double[][]
            {{1 , 0 , 0, 0},
            { 0 ,  Math.cos(Math.toRadians(RxV)) ,  ((-1.0) * Math.sin(Math.toRadians(RxV))), 0},
            {0 ,  Math.sin(Math.toRadians(RxV)) ,  Math.cos(Math.toRadians(RxV)), 0},
            { 0 , 0, 0, 1}};

        double[][] Ry = new double[][]
            {{ Math.cos(Math.toRadians(RyV)) , 0 ,  Math.sin(Math.toRadians(RyV)), 0},
            {  ((-1.0) * Math.sin(Math.toRadians(RyV))) , 1,  Math.cos(Math.toRadians(RyV)), 0},
            {0 , 0 , 1, 0},
            { 0 , 0, 0, 1}};

        double[][] Rz = new double[][]
            {{ Math.cos(Math.toRadians(RzV)) , ((-1.0) * Math.sin(Math.toRadians(RzV))) , 0, 0},
            {  Math.sin(Math.toRadians(RzV)) , Math.cos(Math.toRadians(RzV)), 0, 0},
            {0 , 0 , 1, 0},
            { 0 , 0, 0, 1}};

    //    int[][] resultado = MatrizBase.get(0);
        double[][] resultado = multiplicarMatrices(Traslacion, Zoom);
        resultado = multiplicarMatrices(resultado, Rx);
        resultado = multiplicarMatrices(resultado, Ry);
        resultado = multiplicarMatrices(resultado, Rz);
        ListaMatricesAuxiliar.clear();

        for (int m = 0; m < MatrizBase.size(); m++) {      
            resultado = multiplicarMatrices(resultado, MatrizBase.get(m));
            ListaMatricesAuxiliar.add(clonarMatriz(resultado));

        }
    }

    private static double[][] multiplicarMatrices(double[][] A, double[][] B) {
        double[][] resultado = new double[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                resultado[i][j] = 0;
                for (int k = 0; k < 4; k++) {
                    resultado[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return resultado;
    }

    private static double[][] clonarMatriz(double[][] matriz) {
        double[][] copia = new double[matriz.length][matriz[0].length];
        for (int i = 0; i < matriz.length; i++) {
            System.arraycopy(matriz[i], 0, copia[i], 0, matriz[0].length);
        }
        return copia;
    }
    
    public static void CalcularVertices() {
        ListaVertices.clear();
        for (int i = 0; i < 16; i++) {
            ListaVertices.add(new int[2]);
            ListaVertices.get(i)[0] =  (int) (ListaMatricesAuxiliar.get(i)[0][3] - (ListaMatricesAuxiliar.get(i)[2][3] * Math.cos(Math.toRadians(60))));
            ListaVertices.get(i)[1] =  (int) (ListaMatricesAuxiliar.get(i)[1][3] - (ListaMatricesAuxiliar.get(i)[2][3] * Math.sin(Math.toRadians(60))));
        }
    }
}
