/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProcedimientosArchivos;

import Procedimientos.Bloque;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JFileChooser;

/**
 *
 * @author faked
 */
public class Servidor {
 
    public static String main() {
        try (ServerSocket servidor = new ServerSocket(12345)) {  // Puerto 12345
            System.out.println("Servidor iniciado. Esperando cliente");
            while(true){
                Socket socketCliente = servidor.accept();
                System.out.println("Cliente conectado: " + socketCliente.getInetAddress().getHostAddress());

                // Crea streams de entrada y salida para comunicación
                BufferedReader entrada = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
                PrintWriter salida = new PrintWriter(socketCliente.getOutputStream(), true);

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Seleccionar ubicación para guardar el archivo descomprimido");
                int result = fileChooser.showSaveDialog(null);
                if (result != JFileChooser.APPROVE_OPTION) {
                    return "No se seleccionó ninguna ubicación para guardar el archivo.";
                }
                File archivoSalida = fileChooser.getSelectedFile();
                // Lee mensajes del cliente y responde
                String mensajeCliente = entrada.readLine();
                String Descomprimido = Bloque.Convertir(mensajeCliente);
                BufferedWriter bw = new BufferedWriter(new FileWriter(archivoSalida));
                bw.write(Descomprimido);
                System.out.println("Cliente: " + Descomprimido);
                salida.println("Servidor: Mensaje recibido");

                return Descomprimido;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Mensaje no recibido";
    }
}
