/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProcedimientosArchivos;

import Archivo.Archivos;
import Procedimientos.Bloque;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author faked
 */
public class Cliente {
    public static String main() {
        
        String Archivo = Archivos.SeleccionarArchivo();
        String Comprimido = Bloque.Convertir(Archivo);
        
        try (Socket socket = new Socket("192.168.84.61", 12345)) {  // IP del servidor y puerto
            System.out.println("Conectado al servidor");

            // Crear streams de entrada y salida para la comunicación
            BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);

            salida.println(Comprimido);  // Envía mensaje al servidor
            System.out.println("Servidor: " + entrada.readLine());  // Lee la respuesta del servidor
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Comprimido;
    }
}
