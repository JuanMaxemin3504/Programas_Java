/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Archivo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JFileChooser;

/**
 *
 * @author faked
 */

public class Archivos{

    public static String SeleccionarArchivo() {
        JFileChooser archivo;
        archivo = new JFileChooser();

        int resultado;
        resultado = archivo.showOpenDialog(null);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            try {
                File archivoSeleccionado;
                archivoSeleccionado = archivo.getSelectedFile();

                Scanner cin = new Scanner(archivoSeleccionado);

                String cadena = "";

                while (cin.hasNext()) {
                    cadena += cin.nextLine();
                }
                cin.close();
                return cadena;
            } catch (FileNotFoundException ex) {
               return "Error al abrir el archivo";
            }
        }
        return "Archivo no seleccionado";

    }

}
