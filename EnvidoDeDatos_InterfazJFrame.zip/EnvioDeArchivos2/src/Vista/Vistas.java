package Vista;

import ProcedimientosArchivos.Cliente;
import ProcedimientosArchivos.Servidor;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Vistas extends JFrame {

    // Cuadro de texto para mostrar los resultados de Enviar y Recibir
    private JTextArea textArea;

    public Vistas() {
        super();
        config();
    }

    private void config() {
        setTitle("Enviar y recibir archivos");
        setSize(800, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear los botones
        JButton EnviarArchivo = new JButton("Enviar Archivo");
        EnviarArchivo.addActionListener((e) -> Enviar());

        JButton RecibirArchivo = new JButton("Recibir Archivo");
        RecibirArchivo.addActionListener((e) -> Recibir());

        // Crear y configurar el JTextArea
        textArea = new JTextArea(); // Tamaño inicial (filas, columnas)
        textArea.setMaximumSize(new Dimension(400, 400));
        textArea.setEditable(false); // Solo lectura
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        
        GroupLayout g1 = new GroupLayout(getContentPane());

        g1.setAutoCreateContainerGaps(true);
        g1.setAutoCreateGaps(true);

       // Configuración horizontal
        g1.setHorizontalGroup(
            g1.createSequentialGroup()
                .addGap(100) // Espacio desde la izquierda
                .addGroup(g1.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(textArea) // JTextArea en la parte superior
                    .addGroup(g1.createSequentialGroup()
                        .addComponent(EnviarArchivo) // Botón EnviarArchivo
                        .addGap(20) // Espacio entre botones
                        .addComponent(RecibirArchivo) // Botón RecibirArchivo
                    )
                )
                .addGap(100) // Espacio desde la derecha
        );

        // Configuración vertical
        g1.setVerticalGroup(
            g1.createSequentialGroup()
                .addGap(20) // Espacio en la parte superior
                .addComponent(textArea) // JTextArea
                .addGap(20) // Espacio entre JTextArea y botones
                .addGroup(g1.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(EnviarArchivo) // Botón EnviarArchivo
                    .addComponent(RecibirArchivo) // Botón RecibirArchivo
                )
                .addGap(20) // Espacio en la parte inferior
        );

        // Aplicar el layout
        setLayout(g1);
    }

    private void Enviar() {
        String resultado = Cliente.main(); // Obtener el resultado de Cliente.main
        textArea.setText("Cliente: " + resultado); // Mostrar en el JTextArea
    }

    private void Recibir() {
        String resultado = Servidor.main(); // Obtener el resultado de Servidor.main
        textArea.setText("Servidor: " + resultado); // Mostrar en el JTextArea
    }
}
