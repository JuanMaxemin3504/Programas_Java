    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import DB_Connection.UsuarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author faked
 */
@WebServlet(name = "SvEliminarUsuario", urlPatterns = {"/SvEliminarUsuario"})
public class SvEliminarUsuario extends HttpServlet {

        protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el ID del usuario a eliminar
        int id = Integer.parseInt(request.getParameter("id"));

        // Eliminar el usuario en la base de datos
        UsuarioDAO usuario = new UsuarioDAO();
        boolean exito = usuario.eliminarUsuario(id);

        // Redirigir según el resultado
        if (exito) {
            response.sendRedirect("GestionUsuarios.jsp"); // Regresar a la lista de usuarios
        } else {
            response.sendRedirect("Administrativos.jsp"); // Página de error si algo falla
        }
    }

}
