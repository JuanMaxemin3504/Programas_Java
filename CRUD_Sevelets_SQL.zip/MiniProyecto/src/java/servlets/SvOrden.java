/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import DB_Connection.InventarioDAO;
import Logica.Orden;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelos.Producto;

@WebServlet(name = "SvOrden", urlPatterns = {"/SvOrden"})
public class SvOrden extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        String nombreProducto = request.getParameter("nombreProducto");
        double precioProducto = Double.parseDouble(request.getParameter("precioProducto"));

        Producto producto = new Producto();
        producto.setId(idProducto);
        producto.setNombre(nombreProducto);
        producto.setPrecio(precioProducto);

        List<Orden> ordenes = (List<Orden>) request.getSession().getAttribute("ordenes");
        if (ordenes == null) {
            ordenes = new ArrayList<>();
            request.getSession().setAttribute("ordenes", ordenes);
        }
        Orden.manejarOrden(ordenes, producto);
        response.sendRedirect("Menu.jsp");
    }
}

