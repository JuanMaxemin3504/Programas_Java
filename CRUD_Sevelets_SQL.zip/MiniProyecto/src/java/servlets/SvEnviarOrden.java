import DB_Connection.PedidosDAO;
import DB_Connection.UsuarioDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Logica.Orden;
import java.io.PrintWriter;

@WebServlet(name = "SvEnviarOrden", urlPatterns = {"/SvEnviarOrden"})
public class SvEnviarOrden extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();    
        List<Orden> ordenes = (List<Orden>) request.getSession().getAttribute("ordenes");
        
        int mesa = Integer.parseInt(request.getParameter("mesa"));

        if (ordenes == null || ordenes.isEmpty()) {
            request.getRequestDispatcher("Menu.jsp").forward(request, response);
            out.println("No hay productos en la orden.");
        }
        
        PedidosDAO pedidosDAO = new PedidosDAO();

        try {
            pedidosDAO.enviarPedido(mesa, ordenes);
            request.getSession().removeAttribute("ordenes");
           request.getRequestDispatcher("Pedidos.jsp").forward(request, response);
           out.println("Pedido enviado exitosamente.");

        } catch (SQLException ex) {
            request.getRequestDispatcher("Menu.jsp").forward(request, response);
            out.println("Error al enviar el pedido: " + ex.getMessage());
        }
                
    }
}
