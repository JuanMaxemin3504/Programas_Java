/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import DB_Connection.UsuarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelos.Usuario;

/**
 *
 * @author faked
 */
@WebServlet(name = "SvAgregarUsuario", urlPatterns = {"/SvAgregarUsuario"})
public class SvAgregarUsuario extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }
@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int acceso = Integer.parseInt(request.getParameter("acceso"));

        Usuario usuario = new Usuario(username, password, acceso);
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        boolean exito = usuarioDAO.agregarUsuario(usuario);
        if (exito) {
            response.sendRedirect("GestionUsuarios.jsp");
        } else {
            response.sendRedirect("GestionUsuarios.jsp");
        }
    }

}
