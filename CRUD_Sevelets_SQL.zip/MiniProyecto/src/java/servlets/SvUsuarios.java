/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import DB_Connection.UsuarioDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelos.Usuario;

/**
 *
 * @author faked
 */
@WebServlet(name = "SvUsuarios", urlPatterns = {"/SvUsuarios"})
public class SvUsuarios extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        HttpSession session = request.getSession();

        String usuario = request.getParameter("user");
        String password = request.getParameter("password");


        UsuarioDAO udao = new UsuarioDAO();
        boolean res = udao.select(usuario, password);

        if (res) {
            session.setAttribute("UserSession", usuario);
            session.setAttribute("PasswordSession", password);

            int acceso = udao.selectAcceso(usuario, password);
            if (acceso == 0) {
                response.sendRedirect("Administrativo.jsp");
            } else {
                if (acceso == 2) {
                response.sendRedirect("index.html");
                } else
                response.sendRedirect("Menu.jsp");
            }
        } else {
            response.sendRedirect("index.html");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
         HttpSession session = request.getSession();

        if (session.getAttribute("UserSession") != null && session.getAttribute("PasswordSession") != null) {
            String usuario = session.getAttribute("UserSession").toString();
            String password = session.getAttribute("PasswordSession").toString();
            UsuarioDAO udao = new UsuarioDAO();
            boolean res = udao.select(usuario, password);
            if (res) {
                session.setAttribute("UserSession", usuario);
                session.setAttribute("PasswordSession", password);

                int acceso = udao.selectAcceso(usuario, password);
                if (acceso == 0) {
                    response.sendRedirect("Administrativo.jsp");
                } else {
                    if (acceso == 1) {
                    response.sendRedirect("Menu.jsp");
                    } else
                    response.sendRedirect("Index.html");
                }
            } else {
                response.sendRedirect("index.html");
            }
        } else {
            response.sendRedirect("index.html");
        }
        }

}
