package Logica;

import java.util.List;
import java.util.Objects;

public class Orden {
    private int id;
    private String nombre;
    private double precio;
    private int cantidad;

    public Orden() {}

    public Orden(int id, String nombre, double precio, int cantidad) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Orden orden = (Orden) obj;
        return id == orden.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static void manejarOrden(List<Orden> ordenes, modelos.Producto producto) {
        Orden ord = new Orden(producto.getId(), producto.getNombre(), producto.getPrecio(), 1);

        int index = ordenes.indexOf(ord);
        if (index != -1) {
            Orden existente = ordenes.get(index);
            existente.setCantidad(existente.getCantidad() + 1);
        } else {
            ordenes.add(ord);
        }
    }
}
