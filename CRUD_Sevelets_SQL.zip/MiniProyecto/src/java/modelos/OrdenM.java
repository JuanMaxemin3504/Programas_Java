/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author faked
 */
public class OrdenM {
    
    private int num_pedido;
    private int mesa;
    private double total;
    private String producto;
    private int cantidad;
    private int activo;
    
    public int getNumPedido(){return num_pedido;}
    public void setNumPedido(int num){this.num_pedido = num;}
    
    public int getMesa(){return mesa;}
    public void setMesa(int mesa){this.mesa = mesa;}
    
    public double getTotal(){return total;}
    public void setTotal(double total){this.total = total;}
    
    public String getProducto(){return producto;}
    public void setProducto(String producto){this.producto = producto;}
    
    public int getCantidad (){return cantidad;}
    public void setCantidad(int cantidad){this.cantidad = cantidad;}
    
    public int getActivo(){return activo;}
    public void setActivo (int activo){this.activo = activo;}
}
