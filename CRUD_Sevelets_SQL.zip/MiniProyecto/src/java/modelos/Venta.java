package modelos;

public class Venta {
    private int mesa;
    private double total;

    // Getters y setters
    public int getMesa() { return mesa; }
    public void setMesa(int mesa) { this.mesa = mesa; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
}
