package modelos;

public class Pedido {
    private int pedido;
    private int mesa;
    private int cantidad;
    private String producto;
    private double total;

    public int getIdPedido() { return pedido; }
    public void setIdPedido(int pedido) { this.pedido = pedido; }
    
    public int getMesa() { return mesa; }
    public void setMesa(int mesa) { this.mesa = mesa; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total;}
}
