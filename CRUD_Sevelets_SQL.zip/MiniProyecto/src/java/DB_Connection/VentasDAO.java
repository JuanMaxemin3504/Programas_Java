package DB_Connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Venta;

public class VentasDAO extends ConnectionBD {
    public List<Venta> getVentasPorMesa() {
        List<Venta> ventas = new ArrayList<>();
        String sql = "SELECT mesa, SUM(total) AS total_ventas FROM ventas GROUP BY mesa";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Venta venta = new Venta();
                venta.setMesa(rs.getInt("mesa"));
                venta.setTotal(rs.getDouble("total_ventas"));
                ventas.add(venta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ventas;
    }
}
