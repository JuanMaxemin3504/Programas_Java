package DB_Connection;

import Logica.Orden;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.OrdenM;
import modelos.Pedido;

public class PedidosDAO extends ConnectionBD {
    public PedidosDAO() {
        super();
    }

    public boolean eliminarPedido(int idPedido) {
        String sql = "DELETE FROM pedidos WHERE pedidos.num_pedido = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPedido);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public void enviarPedido(int mesa, List<Orden> ordenes) throws SQLException {
        if (ordenes == null || ordenes.isEmpty()) {
            throw new IllegalArgumentException("La lista de órdenes está vacía.");
        }

        String sql = "INSERT INTO `pedidos` (`num_pedido`, `mesa`, `total`, `id_producto`, `cantidad`, `activo`) VALUES (NULL, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                for (Orden orden : ordenes) {
                    double total = orden.getCantidad() * orden.getPrecio();
                    ps.setInt(1, mesa);
                    ps.setDouble(2, total);
                    ps.setInt(3, orden.getId());
                    ps.setInt(4, orden.getCantidad());
                    ps.setBoolean(5, true);
                    ps.addBatch();
                }
                ps.executeBatch();
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidosDAO.class.getName()).log(Level.SEVERE, "Error al enviar pedido", ex);
            throw ex; // Re-lanzar la excepción para que se pueda manejar en otro nivel
        }
    }
    
    public List<Pedido> getOrdenes() {
        List<Pedido> pedidos = new ArrayList<>();
        String query = "SELECT p.num_pedido, p.mesa, p.cantidad, i.producto, p.total FROM pedidos p JOIN inventario i ON i.id = p.id_producto";

        try (PreparedStatement ps =  getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setMesa(rs.getInt("mesa"));
                pedido.setCantidad(rs.getInt("cantidad"));
                pedido.setProducto(rs.getString("producto"));
                pedido.setTotal(rs.getDouble("total"));
                pedido.setIdPedido(rs.getInt("num_pedido"));
                pedidos.add(pedido);
            }
        }                
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        
       return pedidos;
    }
    
    public List<OrdenM> getPedidos() {
        List<OrdenM> ordenes = new ArrayList<>();
        String query = "SELECT p.num_pedido, p.mesa, p.total, i.producto, p.cantidad, p.activo " +
                       "FROM pedidos p " +
                       "JOIN inventario i ON p.id_producto = i.id";

        try (PreparedStatement ps =  getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                OrdenM orden = new OrdenM();
                orden.setNumPedido(rs.getInt("num_pedido"));
                orden.setMesa(rs.getInt("mesa"));
                orden.setTotal(rs.getDouble("total"));
                orden.setProducto(rs.getString("producto"));
                orden.setCantidad(rs.getInt("cantidad"));
                orden.setActivo(rs.getInt("activo"));   
                ordenes.add(orden);
            }            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return ordenes;
    }
}
