/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DB_Connection;


import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.OrdenM;
import modelos.Usuario;

/**
 *
 * @author Joshua Romo
 */
public class UsuarioDAO extends ConnectionBD{
    public UsuarioDAO(){
        super();
    }
    
    public boolean eliminarUsuario(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean editarUsuario(Usuario usuario) {
        String sql = "UPDATE usuarios SET username = ?, password = ?, acceso = ? WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getUsername());
            pstmt.setString(2, usuario.getPassword());
            pstmt.setInt(3, usuario.getAcceso());
            pstmt.setInt(4, usuario.getId());

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean agregarUsuario(modelos.Usuario usuario) {
        String sql = "INSERT INTO usuarios (id, username, password, acceso) VALUES (NULL, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getUsername());
            pstmt.setString(2, usuario.getPassword());
            pstmt.setInt(3, usuario.getAcceso());

            pstmt.executeUpdate();

            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }               
                
    public List<Usuario> getUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT id, username, acceso FROM usuarios";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setAcceso(rs.getInt("acceso"));
                usuarios.add(usuario);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return usuarios;
    }
                 
    public boolean select(String Usuario, String Password) {
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = getConnection().prepareStatement(
                    "SELECT * FROM usuarios WHERE username = ? AND password = ?;"
            );
            ps.setString(1, Usuario);
            ps.setString(2, Password);
            rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public int getIdMesa(String mesa){
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = getConnection().prepareStatement(
                    "SELECT id FROM usuarios WHERE username = ? LIMIT 1;"
            );
            ps.setString(1, mesa);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            } else {
                return 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }
    
    public int selectAcceso(String Usuario, String Password) {
        PreparedStatement ps;
        ResultSet rs;
        try {
            ps = getConnection().prepareStatement(
                    "SELECT acceso FROM usuarios WHERE username = ? AND password = ? LIMIT 1;"
            );
            ps.setString(1, Usuario);
            ps.setString(2, Password);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("acceso");
            } else {
                return 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }


}
