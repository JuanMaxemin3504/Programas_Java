/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DB_Connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Producto;

/**
 *
 * @author faked
 */
public class InventarioDAO extends ConnectionBD{
    
    public boolean cambiarEstatusProducto(int idProducto) {
        boolean exito = false;
        String sql = "UPDATE inventario SET estatus = CASE WHEN estatus = 1 THEN 0 ELSE 1 END WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idProducto);
            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 0) {
                exito = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return exito;
    }
    
     public List<Producto> getProductosConCategoria() {
        List<Producto> productos = new ArrayList<>();
        String query = "SELECT i.id, i.producto, i.precio, c.nombre, i.estatus " +
                       "FROM inventario i " +
                       "JOIN categoria c ON i.categoria = c.id_categoria";

        try (PreparedStatement ps =  getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Producto producto = new Producto();
                producto.setId(rs.getInt("id"));
                producto.setNombre(rs.getString("producto"));
                producto.setPrecio(rs.getDouble("precio"));
                producto.setCategoria(rs.getString("nombre"));
                producto.setEstatus(rs.getInt("estatus"));

                productos.add(producto);
            }


            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        for(int i = 0; i < productos.size(); i++)
            System.out.println("Producto: " + productos.get(i));
        
        return productos;
    }
    
}
