/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Procedimientos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JuanMa
 */
    public class Compresor {
        char character;
        int posicion;
        int repeticion;
        int primerbyte;
        int segundobyte;
    static String Comprimir(String Entrada){
        int longitud = Entrada.length();
        List<Compresor> lista = new ArrayList<>(); 
        int pos = 0, repeticion, inicio, simbolo; 
        boolean repet;
        while(pos < longitud){
            repet = false;
            simbolo = 0;
            repeticion = 0;
            inicio = pos;
            if(pos < 7){
                for(int i = 0; i < inicio; i++){
                    if(Entrada.charAt(i) == Entrada.charAt(pos)){
                        repeticion++;
                        pos++;
                        repet = true;
                        simbolo = inicio - i;
                    }else{
                        if(repet == true){
                            simbolo--;
                            break;
                        }
                    }
                }
                if(repet == true){
                    lista.add(new Compresor(Entrada.charAt(pos), simbolo + repeticion, repeticion));
                }else{
                    lista.add(new Compresor(Entrada.charAt(pos), 0, 0));
                }
            }
            else{
                for(int i = pos - 7; i < inicio; i++){
                    if(Entrada.charAt(i) == Entrada.charAt(pos)){
                        repeticion++;
                        pos++;
                        repet = true;
                        simbolo = inicio - i;
                    }
                    else{
                        if(repet == true){
                            simbolo--;
                            break;
                        }
                    }
                }
                if(repet == true){
                    lista.add(new Compresor(Entrada.charAt(pos), simbolo + repeticion, repeticion));
                }else{
                    lista.add(new Compresor(Entrada.charAt(pos), 0, 0));
                }
            }
//            System.out.println(Entrada.substring(pos));
            if(pos == longitud - 2){
                lista.add(new Compresor(Entrada.charAt(pos + 1), 0, 0));
//                System.out.println(Entrada.substring(pos + 1));
                break;
            }
            pos++;
        }
        
        return DatosACadena(lista);
    }
    
    static String DatosACadena(List<Compresor> lista){
        String resultado = "";
        List<Compresor> lista2 = new ArrayList<>(); 
        System.out.println("Contenido de la lista:");
        for (Compresor comp : lista) {
//           System.out.println(comp.character + " , " + comp.posicion + " , " + comp.repeticion);
            int byte1 = comp.character;
            String parte1 = Integer.toBinaryString(comp.posicion);
            String parte2 = Integer.toBinaryString(comp.repeticion);
            for(int i = parte1.length(); i < 3; i++){parte1 = "0" + parte1;}
            for(int i = parte2.length(); i < 5; i++){parte2 = "0" + parte2;}
            String byte2S = parte1 + parte2;
            int Binario = 0;
            int FinalDato = 7, XDato = 1;
            for (double i = 0; i < 8; i++)
            {
                if (byte2S.charAt(FinalDato) == '1')
                {
                    Binario = Binario + XDato;
                }
                XDato = XDato * 2;
                FinalDato--;
            }
            lista2.add(new Compresor(byte1, Binario));
//            System.out.println(byte1 + " , " + Binario);
//            System.out.println("");
        }
        for (Compresor comp2 : lista2){
            resultado = resultado + comp2.primerbyte + "," + comp2.segundobyte + " "; 
        }
        return resultado;
    }
    
    public Compresor(int primero, int segundo) {
        this.primerbyte = primero;
        this.segundobyte = segundo;
    }    
        
    public Compresor(char character, int number1, int number2) {
        this.character = character;
        this.posicion = number1;
        this.repeticion = number2;
    }
}