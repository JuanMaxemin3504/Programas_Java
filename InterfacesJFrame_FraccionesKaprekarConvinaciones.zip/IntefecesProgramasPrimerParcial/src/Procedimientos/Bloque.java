/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Procedimientos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JuanMa
 */
public class Bloque {
    public static String Convertir(String Entrada){
        boolean Descompri = false, Compri = false;
        int longitud = Entrada.length();
        if(Entrada.endsWith(" ")){
            Entrada = Entrada.substring(0, longitud - 1);
        }
        String [] Partes = Entrada.split(" ");
        try{ 
            for(String partes : Partes){
                String [] comprobacion = partes.split(",");
                int numero1 = Integer.parseInt(comprobacion[0]);
                int numero2 = Integer.parseInt(comprobacion[1]);
            }
            Descompri = true;
        }
        catch(ArrayIndexOutOfBoundsException | NumberFormatException ex){
            Descompri = false;
        }
        for(String partes : Partes){
            if(partes.matches("^[a-zA-Z]+$")){
                Compri = true;
            }
        }
        if(Compri == true){return Compresor.Comprimir(Entrada);}
        if(Descompri == true){return Descompresor.Descomprimir(Entrada);}
        return Errores(1);
    }
    
    static String Errores(int error){
        if(error == 1){return "Formato ingresado incorrectamente";}
        return "Error no encontrado";
    }
}
