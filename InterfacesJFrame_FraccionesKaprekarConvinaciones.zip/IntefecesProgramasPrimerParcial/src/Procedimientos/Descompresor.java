/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Procedimientos;

/**
 *
 * @author JuanMa
 */
public class Descompresor {
    static String Descomprimir(String Entrada){
        String resultado = "";
        String [] Partes = Entrada.split(" ");
        for (int i = 0; i < Partes.length; i++){
            String [] comprobacion = Partes[i].split(",");
            int numero1 = Integer.parseInt(comprobacion[0]);
            int numero2 = Integer.parseInt(comprobacion[1]);
            char caracter = (char) numero1;
            String binario = Integer.toBinaryString(numero2);
            for(int x = binario.length(); x < 8; x++){binario = "0" + binario;}
            String binario1 = binario.substring(0,3);
            String binario2 = binario.substring(3);            
            int posicion = 0;
            int FinalDato1 = 2, XDato = 1;
            for (double z = 0; z < 3; z++)
            {
                if (binario1.charAt(FinalDato1) == '1')
                {
                    posicion = posicion + XDato;
                }
                XDato = XDato * 2;
                FinalDato1--;
            }
            int repeticion = 0;
            int FinalDato2 = 4, XDato2 = 1;
            for (double z = 0; z < 5; z++)
            {
                if (binario2.charAt(FinalDato2) == '1')
                {
                    repeticion = repeticion + XDato2;
                }
                XDato2 = XDato2 * 2;
                FinalDato2--;
            }
            if(repeticion > 0){
                int pos = resultado.length() - posicion;
                for(int a  = repeticion; a > 0; a--){
                    resultado = resultado + resultado.charAt(pos);
                    pos++;
                }
            }
            resultado = resultado + caracter;
         }

        return resultado;
    }
    
}
