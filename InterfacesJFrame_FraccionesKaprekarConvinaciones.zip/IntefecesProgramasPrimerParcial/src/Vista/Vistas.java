/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Fracciones.Fraccion;
import static GeneradorPermutaciones.GeneradorCombinaciones.GenerarPermutaciones;
import Procedimientos.Bloque;
import Secuencia.Kaprekar;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author JuanMa
 */
public class Vistas extends JFrame {
    
    int x = 0;
    int y = 0;
    
    public Vistas(){ 
        super();
        /* Inicializacion de propiedades y procesos */
        /* configuracion */
        config();
    }
    private void config() {
        setTitle("Interfas 4 programas");
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        JButton Fracciones = new JButton("Fracciones A Texto");
        JButton Kaprekar = new JButton("Constante de keplar");
        JButton Permutaciones = new JButton("Combinaciones");
        JButton Compresion = new JButton("Compresion de datos");
        Fracciones.addActionListener( (e) -> onClickProgramaFracciones() );
        Kaprekar.addActionListener( (e) -> onClickProgramaKaprekar() );
        Permutaciones.addActionListener( (e) -> onClickProgramaPermutaciones() );
        Compresion.addActionListener( (e) ->  onClickProgramaComprecion() );
        
        GroupLayout g1 = new GroupLayout (getContentPane()); 
        
        g1.setAutoCreateContainerGaps(true);
        g1.setAutoCreateGaps(true);
        
        
        g1.setHorizontalGroup
        (
            g1.createSequentialGroup()
            .addGap(160)
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(Fracciones)
                    .addComponent(Kaprekar)
            )
            .addGroup
            (
                    g1.createParallelGroup()
                    .addComponent(Permutaciones)
                    .addComponent(Compresion)
            )     
        );
        
        g1.setVerticalGroup
        (
            g1.createSequentialGroup()
            .addGap(30)
            .addGroup
            (
                g1.createParallelGroup()
                .addComponent(Fracciones)
                .addComponent(Permutaciones)
            )
            .addGroup
            (
                g1.createParallelGroup()
                .addComponent(Kaprekar)
                .addComponent(Compresion)
            )
        );
        setLayout(g1);
    
    }
   
    
    private void onClickProgramaFracciones() {
        getContentPane().removeAll();

        JLabel label = new JLabel("Ingrese fracción:");
        JTextField textField = new JTextField(10);
        textField.setMaximumSize(new Dimension(500,30));
        JButton ejecutar = new JButton("Procesar");
        JButton volver = new JButton("Volver");
        
        JLabel resultado = new JLabel("");

        ejecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Fraccion operacion = new Fraccion();
                operacion.texto = textField.getText();
                String resultado2 = operacion.Fracciones();
                resultado.setText(resultado2);
            }   
        });
        
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 getContentPane().removeAll();
                 config();
            }
        });

        // Layout para el nuevo contenido
        GroupLayout g2 = new GroupLayout(getContentPane());
        g2.setAutoCreateContainerGaps(true);
        g2.setAutoCreateGaps(true);

        g2.setHorizontalGroup(
            g2.createSequentialGroup()
            .addGap(10)
            .addGroup(
                g2.createParallelGroup()
                .addComponent(label)
                .addComponent(textField)
                .addGroup
                (
                    g2.createSequentialGroup()
                    .addComponent(ejecutar)
                    .addComponent(volver)
                )
                .addComponent(resultado)
            )
        );

        g2.setVerticalGroup(
            g2.createSequentialGroup()
            .addGap(30)
            .addComponent(label)
            .addComponent(textField)
            .addGroup
            (
                g2.createParallelGroup()
                .addComponent(ejecutar)
                .addComponent(volver)
            )
            .addComponent(resultado)
            
        );

        // Establecer el nuevo layout
        setLayout(g2);

        // Refrescar la ventana
        revalidate();
        repaint();
    }
    private void onClickProgramaKaprekar(){
       getContentPane().removeAll();

        JLabel label = new JLabel("Ingrese 4 numeros:");
        JTextField textField = new JTextField(10);
        textField.setMaximumSize(new Dimension(500,30));
        JButton ejecutar = new JButton("Procesar");
        JButton volver = new JButton("Volver");
        
        JLabel resultado = new JLabel("");

        ejecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Entrada = textField.getText();
                String resultado2 = Kaprekar.ComprobarEntrada(Entrada);
                resultado.setText(resultado2);
            }   
        });
        
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 getContentPane().removeAll();
                 config();
            }
        });

        // Layout para el nuevo contenido
        GroupLayout g2 = new GroupLayout(getContentPane());
        g2.setAutoCreateContainerGaps(true);
        g2.setAutoCreateGaps(true);

        g2.setHorizontalGroup(
            g2.createSequentialGroup()
            .addGap(10)
            .addGroup(
                g2.createParallelGroup()
                .addComponent(label)
                .addComponent(textField)
                .addGroup
                (
                    g2.createSequentialGroup()
                    .addComponent(ejecutar)
                    .addComponent(volver)
                )
                .addComponent(resultado)
            )
        );

        g2.setVerticalGroup(
            g2.createSequentialGroup()
            .addGap(30)
            .addComponent(label)
            .addComponent(textField)
            .addGroup
            (
                g2.createParallelGroup()
                .addComponent(ejecutar)
                .addComponent(volver)
            )
            .addComponent(resultado)
            
        );

        // Establecer el nuevo layout
        setLayout(g2);

        // Refrescar la ventana
        revalidate();
        repaint();
    }
    private void onClickProgramaPermutaciones(){
       getContentPane().removeAll();

        JLabel label = new JLabel("Ingrese texto:");
        JTextField textField = new JTextField(10);
        textField.setMaximumSize(new Dimension(500,30));
        JButton ejecutar = new JButton("Procesar");
        JButton volver = new JButton("Volver");
        
        JLabel resultado = new JLabel("");

        ejecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String texto = textField.getText();
                char[] caracteres = texto.toCharArray();
                List<String> combinaciones = new ArrayList<>();
                GenerarPermutaciones(caracteres, 0, caracteres.length - 1, combinaciones);

                String resultadoVista = "<html>";
                int n = 1;
                for (String elemento : combinaciones) {
                    resultadoVista += String.format("%s: %s", n, elemento) + "<br>";
                    n++;
                }
                 resultadoVista += "<html>";
                resultado.setText(resultadoVista);
            }   
        });
        
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 getContentPane().removeAll();
                 config();
            }
        });

        // Layout para el nuevo contenido
        GroupLayout g2 = new GroupLayout(getContentPane());
        g2.setAutoCreateContainerGaps(true);
        g2.setAutoCreateGaps(true);

        g2.setHorizontalGroup(
            g2.createSequentialGroup()
            .addGap(10)
            .addGroup(
                g2.createParallelGroup()
                .addComponent(label)
                .addComponent(textField)
                .addGroup
                (
                    g2.createSequentialGroup()
                    .addComponent(ejecutar)
                    .addComponent(volver)
                )
                .addComponent(resultado)
            )
        );

        g2.setVerticalGroup(
            g2.createSequentialGroup()
            .addGap(30)
            .addComponent(label)
            .addComponent(textField)
            .addGroup
            (
                g2.createParallelGroup()
                .addComponent(ejecutar)
                .addComponent(volver)
            )
            .addComponent(resultado)
            
        );

        // Establecer el nuevo layout
        setLayout(g2);

        // Refrescar la ventana
        revalidate();
        repaint();
    }
    private void onClickProgramaComprecion(){
       getContentPane().removeAll();

        JLabel label = new JLabel("Ingrese texto:");
        JTextField textField = new JTextField(10);
        textField.setMaximumSize(new Dimension(500,30));
        JButton ejecutar = new JButton("Procesar");
        JButton volver = new JButton("Volver");
        
        JTextField resultado = new JTextField();
        resultado.setMaximumSize(new Dimension(500,30));

        ejecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String texto = textField.getText();
                String resultado2 = (Bloque.Convertir(texto));
                resultado.setText(resultado2);
            }   
        });
        
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 getContentPane().removeAll();
                 config();
            }
        });

        // Layout para el nuevo contenido
        GroupLayout g2 = new GroupLayout(getContentPane());
        g2.setAutoCreateContainerGaps(true);
        g2.setAutoCreateGaps(true);

        g2.setHorizontalGroup(
            g2.createSequentialGroup()
            .addGap(10)
            .addGroup(
                g2.createParallelGroup()
                .addComponent(label)
                .addComponent(textField)
                .addGroup
                (
                    g2.createSequentialGroup()
                    .addComponent(ejecutar)
                    .addComponent(volver)
                )
                .addComponent(resultado)
            )
        );

        g2.setVerticalGroup(
            g2.createSequentialGroup()
            .addGap(30)
            .addComponent(label)
            .addComponent(textField)
            .addGroup
            (
                g2.createParallelGroup()
                .addComponent(ejecutar)
                .addComponent(volver)
            )
            .addComponent(resultado)
            
        );

        // Establecer el nuevo layout
        setLayout(g2);

        // Refrescar la ventana
        revalidate();
        repaint();
    }
    
    
}
