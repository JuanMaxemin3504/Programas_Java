/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GeneradorPermutaciones;

import java.util.List;

/**
 *
 * @author JuanMa
 */
public class GeneradorCombinaciones {
    public static void GenerarPermutaciones(char[] caracteres, int inicio, int fin, List<String> combinaciones) {
        if (inicio == fin) {
            combinaciones.add(new String(caracteres));
        } else {
            for (int i = inicio; i <= fin; i++) {
                Intercambiar(caracteres, inicio, i);
                GenerarPermutaciones(caracteres, inicio + 1, fin, combinaciones);
                Intercambiar(caracteres, inicio, i); // Deshacer el intercambio
            }
        }
    }

    // Función para intercambiar dos caracteres en el arreglo
    public static void Intercambiar(char[] caracteres, int i, int j) {
        char temp = caracteres[i];
        caracteres[i] = caracteres[j];
        caracteres[j] = temp;
    }
}
