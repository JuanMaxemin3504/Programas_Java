/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package juegogatocliente;

/**
 *
 * @author faked
 */
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.SwingUtilities;

public class JuegoGatoCliente extends JFrame {
    
    ImageIcon iconoX = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/Imagen_Cruz.png"));
    ImageIcon iconoO = new ImageIcon(getClass().getClassLoader().getResource("Imagenes/Imagen_Circulo.png"));
    
    private static final String SERVER_ADDRESS = "192.168.84.61"; // Cambia esto a "127.0.0.1" si es necesario
    private static final int PORT = 12345;
    private char[][] tablero = new char[3][3];
    private DataOutputStream out;
    private DataInputStream in;
    private JButton[][] botones = new JButton[3][3]; // Declaración como campo de clase

    public JuegoGatoCliente() {
        // Configuración de la ventana del cliente
        setTitle("Cliente - Juego de Gato");
        setSize(800, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializar el tablero de botones
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botones[i][j] = new JButton("");
                botones[i][j].setPreferredSize(new Dimension(140, 140));
                botones[i][j].setMaximumSize(new Dimension(140, 140));
                final int x = i, y = j;
                botones[i][j].addActionListener(e -> hacerMovimiento(x, y));
                add(botones[i][j]);
            }
        }
        
        GroupLayout g1 = new GroupLayout(getContentPane());
        g1.setAutoCreateContainerGaps(true);
        g1.setAutoCreateGaps(true);

        // Configuración horizontal
        g1.setHorizontalGroup(
            g1.createSequentialGroup()
                .addGap(160)
                .addGroup(
                    g1.createParallelGroup()
                        .addGroup(
                            g1.createSequentialGroup()
                                .addComponent(botones[0][0])
                                .addComponent(botones[0][1])
                                .addComponent(botones[0][2])
                        )
                        .addGroup(
                            g1.createSequentialGroup()
                                .addComponent(botones[1][0])
                                .addComponent(botones[1][1])
                                .addComponent(botones[1][2])
                        )
                        .addGroup(
                            g1.createSequentialGroup()
                                .addComponent(botones[2][0])
                                .addComponent(botones[2][1])
                                .addComponent(botones[2][2])
                        )
                )
        );

        // Configuración vertical
        g1.setVerticalGroup(
            g1.createSequentialGroup()
                .addGap(50)
                .addGroup(
                    g1.createParallelGroup()
                        .addComponent(botones[0][0])
                        .addComponent(botones[0][1])
                        .addComponent(botones[0][2])
                )
                .addGroup(
                    g1.createParallelGroup()
                        .addComponent(botones[1][0])
                        .addComponent(botones[1][1])
                        .addComponent(botones[1][2])
                )
                .addGroup(
                    g1.createParallelGroup()
                        .addComponent(botones[2][0])
                        .addComponent(botones[2][1])
                        .addComponent(botones[2][2])
                )
        );

        setLayout(g1);

        // Inicializar la matriz de tablero
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = ' ';
            }
        }

        // Conectar al servidor
        try {
            Socket socket = new Socket(SERVER_ADDRESS, PORT);
            out = new DataOutputStream(socket.getOutputStream());
            in = new DataInputStream(socket.getInputStream());

            // Crear un hilo separado para recibir movimientos del servidor
            new Thread(() -> {
                try {
                    while (true) {
                        int x = in.readInt();
                        int y = in.readInt();
                        SwingUtilities.invokeLater(() -> {
                            if (tablero[x][y] == ' ') {
                                tablero[x][y] = 'O';
                                botones[x][y].setIcon(iconoO);
                                verificarFinJuego();
                            }
                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Hacer la ventana visible
        setVisible(true);
    }

    private void hacerMovimiento(int x, int y) {
        if (tablero[x][y] == ' ') {
            tablero[x][y] = 'X'; // El cliente juega con 'X'
            botones[x][y].setIcon(iconoX);

            try {
                out.writeInt(x);
                out.writeInt(y);
                verificarFinJuego();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void verificarFinJuego() {
        // Verificar si el cliente ha ganado
        if (verificarGanador('X')) {
            JOptionPane.showMessageDialog(this, "¡Has ganado!");
            finalizarJuego();
        } 
        // Verificar si el servidor (CPU) ha ganado
        else if (verificarGanador('O')) {
            JOptionPane.showMessageDialog(this, "¡La CPU ha ganado!");
            finalizarJuego();
        } 
        // Verificar si hay un empate
        else if (esEmpate()) {
            JOptionPane.showMessageDialog(this, "Empate.");
            finalizarJuego();
        }
    }

    // Método para finalizar el juego y cerrar la aplicación
    private void finalizarJuego() {
        // Cerrar flujos y socket
        try {
            if (out != null) out.close();
            if (in != null) in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Cerrar la ventana
        dispose(); // Cerrar la ventana
        System.exit(0); // Finalizar la aplicación
    }

    // Método para verificar si hay un ganador
    private boolean verificarGanador(char jugador) {
        // Verificar filas, columnas y diagonales
        for (int i = 0; i < 3; i++) {
            if ((tablero[i][0] == jugador && tablero[i][1] == jugador && tablero[i][2] == jugador) || // Filas
                (tablero[0][i] == jugador && tablero[1][i] == jugador && tablero[2][i] == jugador)) { // Columnas
                return true;
            }
        }
        // Diagonales
        return (tablero[0][0] == jugador && tablero[1][1] == jugador && tablero[2][2] == jugador) ||
               (tablero[0][2] == jugador && tablero[1][1] == jugador && tablero[2][0] == jugador);
    }

    // Método para verificar si hay un empate
    private boolean esEmpate() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (tablero[i][j] == ' ')
                    return false;
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(JuegoGatoCliente::new);
    }
}

