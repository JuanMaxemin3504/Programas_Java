/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fraccionestexto;

import Fracciones.Fraccion;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author JuanMa
 */
public class FraccionesTexto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Fraccion operacion = new Fraccion();
       Scanner cin;
       cin = new Scanner(System.in);
       operacion.texto = cin.nextLine();
       //operacion.texto = "cuarenta dieciseisavos por cuarenta dieciseisavos";
       String resultado = operacion.Fracciones();
       System.out.println(resultado);
       //noventa y nueve noventa y nueveavos mas noventa y nueve noventa y nueveavos       
    }
    
}
