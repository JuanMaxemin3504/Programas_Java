/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fracciones;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author JuanMa
 */
public class Fraccion {
    public String texto;
    int numerador;
    int denominador;

    
    public Fraccion(){
        numerador = 0;
        denominador = 0;
        texto = "vacion";
    }
    
    
    public String Fracciones(){
        Fraccion f1 = new Fraccion();
        Fraccion f2 = new Fraccion();
        Fraccion f3 = new Fraccion();
        String resultado = "vacio",operacion = "vacio";
        String OperacionSuma = "mas";
        String OperacionResta = "menos";
        String OperacionMultiplicacion = "por";
        String OperacionDivision = "entre";

        String regex1 = ".*\\b" + OperacionSuma + "\\b.*";
        String regex2 = ".*\\b" + OperacionResta + "\\b.*";
        String regex3 = ".*\\b" + OperacionMultiplicacion + "\\b.*";
        String regex4 = ".*\\b" + OperacionDivision + "\\b.*";        

        String[] partes = null;
        int repeticiones = 0;
        Fraccion frac = new Fraccion();
        boolean banderaOperando = false;
        if (texto.matches(regex1)) {
            repeticiones = frac.ContarRepeticiones(texto,OperacionSuma);
            if(repeticiones > 1){ return "Operando incluido mas de una vez";}
            partes = texto.split(OperacionSuma);
            operacion = "+"; 
            banderaOperando = true;
        }
        if (texto.matches(regex2)) { 
            repeticiones = frac.ContarRepeticiones(texto,OperacionResta);
            if(repeticiones > 1 || banderaOperando == true){ return "Operando incluido mas de una vez";}
            partes = texto.split(OperacionResta);
            operacion = "-"; 
            banderaOperando = true;
        }
        if (texto.matches(regex3)) { 
            repeticiones = frac.ContarRepeticiones(texto,OperacionMultiplicacion);
            if(repeticiones > 1 || banderaOperando == true){ return "Operando incluido mas de una vez";}
            partes = texto.split(OperacionMultiplicacion);
            operacion = "*"; 
            banderaOperando = true;
        }
        if (texto.matches(regex4)) { 
            repeticiones = frac.ContarRepeticiones(texto,OperacionDivision);
            if(repeticiones > 1 || banderaOperando == true){ return "Operando incluido mas de una vez";}
            partes = texto.split(OperacionDivision);
            operacion = "/"; 
            banderaOperando = true;
        }
        
        if(partes[0] == "" || partes[1] == "") { return "Operando ingresado incorrectamente"; }
        if(partes[1] == null) { return "Operando ingresado incorrectamente"; }
        f1.texto = partes[0];
        f1.texto = f1.TextoANumeros();
        if(f1.texto == "1"){ return "Numerador de la primera fraccion ingresado incorrectamente";}
        if(f1.texto == "2"){ return "Denominador de la primera fraccion ingresado incorrectamente";}
        if(f1.texto == "3"){ return "Primera fraccion ingresado incorrectamente";}
        if(f1.texto == "4"){ return "Denominador de la primera fraccion incorrecto ya que es cero";}
        f2.texto = partes[1];
        f2.texto = f2.TextoANumeros();
        if(f2.texto == "1"){ return "Numerador de la segunda fraccion ingresado incorrectamente";}
        if(f2.texto == "2"){ return "Denominador de la segunda fraccion ingresado incorrectamente";}
        if(f2.texto == "3"){ return "Segunda fraccion ingresado incorrectamente";}
        if(f1.texto == "4"){ return "Denominador de la segunda fraccion incorrecto ya que es cero";}
        resultado = f3.CalcularOperacion(f1.texto, f2.texto, operacion);
        if(resultado == "00"){return "Operacion invalida ya que el denominador da 0";}
        String[] partes3 = resultado.split(" ");
        String Enteros = partes3[0];
        int enteros = Integer.parseInt(Enteros);
        System.out.println(partes3[1]);
        resultado = "";
        if(enteros == 1){
            resultado = "menos";
        }
        String[] fraccionSeparada = partes3[1].split("/");
        resultado = resultado + f1.NumerosATexto(fraccionSeparada[0], false, false);
        if(resultado == ""){resultado = resultado + "cero";}
        resultado = resultado + " " + f1.NumerosATexto(fraccionSeparada[1], true, false);        
        return resultado;
    }
    
    String TextoANumeros(){
        int Marcador = 0;
        String convercion = "0/0",clave1 = "avos",clave2 = "vos";
        boolean banderaNumerador = false , banderaDenominador = false, banderaNoNumerosExtra = false;
        String[] UnDigitoNumerador = {"un","uno","dos","tres","cuatro","cinco","seis","siete","ocho","nueve"};
        String[] DosDigitosDiez = {"once","doce","trece","catorce","quince"};
        String[] DosDigitosCompletos = {"diez","veinte","treinta","cuarenta","cincuenta","sesenta","setenta", "ochenta", "noventa"};
        String[] UnDigitoDenominador = {"entero","medio","tercio","cuarto","quinto","sexto","septimo","octavo","noveno"};
        String[] UnDigitoDenominador2 = {"enteros","medios","tercios","cuartos","quintos","sextos","septimos","octavos","novenos"};
        String[] DosDigitoDenominador = {"dieciseis","diecisiete","dieciocho","diecinueve"};
        String[] partes = texto.split("\\s+");
        if(partes[0] == ""){Marcador++;}
        int longitud = partes.length;
        if( longitud > 7) {return "3";}
        for(int i = 0; i < 5; i++){
            if(partes[Marcador].matches(DosDigitosDiez[i])){ 
                numerador += (i + 11);
                Marcador++;
                banderaNumerador = true;
                break;
            }
        }
        for(int i = 0; i < 9; i++){
            if(partes[Marcador].matches(DosDigitosCompletos[i])){ 
                numerador += (i + 1) * 10;
                Marcador++;
                banderaNumerador = true;
                break;
            }
        }
        if(partes[Marcador].matches("y")){ Marcador++; }
        for(int i = 0; i < 10; i++){
            if(partes[Marcador].matches(UnDigitoNumerador[i])){ 
                if(i == 0){
                    numerador++;
                }
                numerador += i;
                Marcador++;
                banderaNumerador = true;
                break;
            }
        }
        if(partes[Marcador].matches("cero") && banderaNumerador == false){
            numerador = 0;
            Marcador++;
            banderaNumerador = true;
        }
        if(banderaNumerador == false) { return "1";}
        
        String palabra = partes[Marcador];
        String[] partes2 = palabra.split(clave1);
        palabra = partes2[0];
        if(palabra.matches("decimos")){ 
                denominador = 10;
                banderaDenominador = true;
                Marcador++;
        }
        for(int i = 0; i < 5; i++){
            if(palabra.matches(DosDigitosDiez[i])){ 
                denominador += i + 11;
                banderaDenominador = true;
                Marcador++;
                break;
            }
        }
        for(int i = 0; i < 4; i++){
            if(palabra.matches(DosDigitoDenominador[i])){ 
                denominador += i + 16;
                banderaDenominador = true;
                Marcador++;
                break;
            }
        }
        for(int i = 0; i < 9; i++){
            if(palabra.matches(DosDigitosCompletos[i])){ 
                denominador += (i + 1) * 10;
                banderaDenominador = true;
                Marcador++;
                banderaNoNumerosExtra = true;
                Marcador++;
                break;
            }
        }
        if(longitud == Marcador){ return convercion = numerador + "/" + denominador; }        
        palabra = partes[Marcador];
        partes2 = palabra.split(clave2);
        palabra = partes2[0];
        for(int i = 0; i < 9; i++){
            if(palabra.matches(DosDigitosCompletos[i])){ 
                if(banderaNoNumerosExtra == true) { return "3";}
                denominador += (i + 1) * 10;
                banderaDenominador = true;
                Marcador++;
                break;
            }
        }
        if(longitud == Marcador){ return convercion = numerador + "/" + denominador; }
        if(partes[Marcador].matches("y")){ Marcador++; }
        palabra = partes[Marcador];
        partes2 = palabra.split(clave1);
        palabra = partes2[0];
        for(int i = 0; i < 9; i++){
            if(palabra.matches(UnDigitoDenominador[i])){ 
                denominador += (i + 1);
                banderaDenominador = true;
                Marcador++;
                break;
            }
        } 
        for(int i = 0; i < 9; i++){
            if(palabra.matches(UnDigitoDenominador2[i])){ 
                denominador += (i + 1);
                banderaDenominador = true;
                Marcador++;
                break;
            }
        }
        for(int i = 0; i < 10; i++){
            if(palabra.matches(UnDigitoNumerador[i])){ 
                if(i == 0){
                    denominador++;
                }
                denominador += i;
                banderaDenominador = true;
                Marcador++;
                break;
            }
        }
        if(longitud != Marcador){ return "3"; }
        if(banderaDenominador == false) {return "2";}
        convercion = numerador + "/" + denominador;
        return convercion;
    }
    
    String CalcularOperacion(String f1, String f2, String operando){
        String resultado = "0";
        String[] fraccion1 = f1.split("/");
        String[] fraccion2 = f2.split("/");
        int numerador1 = Integer.parseInt(fraccion1[0]);
        int denominador1 = Integer.parseInt(fraccion1[1]);
        int numerador2 = Integer.parseInt(fraccion2[0]);
        int denominador2 = Integer.parseInt(fraccion2[1]);
        if(operando == "+"){
            numerador = numerador1*denominador2 + numerador2 * denominador1;
            denominador = denominador1*denominador2;
        }
        if(operando == "-"){
            numerador = numerador1*denominador2 - numerador2 * denominador1;
            denominador = denominador1*denominador2;
        }
        if(operando == "*"){
            numerador = numerador1 * numerador2;
            denominador = denominador1*denominador2;
        }
        if(operando == "/"){
            numerador = numerador1 * denominador2;
            denominador = denominador1 * numerador2;
        }
        int i = 2, enteros = 0;
//        while(numerador > denominador){
//            enteros++;
//            numerador -= denominador;
//        }
//        if(numerador == denominador){
//            enteros++;
//            numerador = 0;
//            denominador = 0;
//        }
//        while(i <= numerador){
//            if((numerador % i == 0) && (denominador % i == 0)){
//                numerador /= i;
//                denominador /= i;
//            }else{ i++; }
//        }
        if(numerador < 0  && denominador < 0){
            numerador *= -1;
            denominador *= -1;
        }
        else {
            if(numerador < 0){
                enteros = 1;
                numerador *= -1;
            }if(denominador < 0){
                denominador *= -1;
                enteros = 1;
            }
        }
        resultado = enteros + " " + numerador + "/" + denominador;
        if(denominador == 0){return "00";}
        return resultado;
    }
    
    String NumerosATexto(String numeros, boolean denominador,boolean enteros){
        String resultado;
        resultado = "";
        boolean BanderaCientos = false, MayorQue10 = false, Decenas = false, Solo = false, num = true;
        String[] UnDigito = {"uno","dos","tres","cuatro","cinco","seis","siete","ocho","nueve"};
        String[] UnDigitoSolo = {"enteros","medios","tercios","cuartos","quintos","sextos","septimos","octavos","novenos"};
        String[] Cientos = {"cien","docientos","trecientos","cuatrocientos","quinientos","seiscientos","sietecientos","ochocientos","nuevecientos"};
        String[] DosDigitosCompletos = {"diez","veinte","treinta","cuarenta","cincuenta","sesenta","setenta", "ochenta", "noventa"};   
        String[] DosDigitosDiez = {"once","doce","trece","catorce","quince","dieciseis","diecisiete","dieciocho","diecinueve"};
        if(numeros == "0"){ return "";}
        int longitud = numeros.length();
        int inicio = 0;
        int digito = 0;
        if(longitud > 1){
             digito = Character.getNumericValue(numeros.charAt(longitud -1));
            digito = digito + Character.getNumericValue(numeros.charAt(longitud -2)) * 10;
        }
        if(longitud == 5){
            for(int i = 0; i < 10; i++){
                if(Character.getNumericValue(numeros.charAt(inicio+1)) == i){
                    if(i == 0){ resultado = "diez"; }
                    else{
                        resultado = resultado + DosDigitosDiez[i - 1];
                        MayorQue10 = true;
                    }
                    resultado = resultado + "mil ";
                }
            }
            inicio += 2;
            longitud -= 2;
        }
        if(longitud == 4){
            for(int i = 0; i < 10; i++){
                if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                    if(i == 0){ resultado = ""; }
                    else{
                        if(i == 1){ 
                            resultado = "mil "; 
                            num = false;
                        }
                        else{ 
                            num = false;
                            resultado = UnDigito[i-1] + "mil "; 
                        }
                        MayorQue10 = true;
                    }
                }
            }
            inicio++;
            longitud--;
        }
        if(longitud == 3){
            for(int i = 0; i < 10; i++){
                if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                    if(i == 0){ resultado = resultado + ""; }
                    else{ 
                        resultado = resultado + Cientos[i-1];
                        num = false;
                    }
                    if(i == 1){ BanderaCientos = true;}
                    MayorQue10 = true;
                }
            }
            inicio++;
            longitud--;
        }
        if(digito > 10 && digito < 20){
            for(int i = 0; i < 9; i++){
                if(Character.getNumericValue(numeros.charAt(inicio + 1)) == i){
                    if(i == 0){ resultado = resultado + ""; }
                    else{
                        if(BanderaCientos == true){ resultado = resultado + "to";}
                        resultado = resultado + " " + DosDigitosDiez[i - 1];
                        num = false;
                    }
                    if(denominador == true){resultado = resultado + "avos";}
                    return resultado;
                }
            }
        }else{
            if(longitud == 2){
                for(int i = 0; i < 10; i++){
                    if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                        if(i == 0){ resultado = resultado + ""; }
                        else{ 
                            if(BanderaCientos == true){ resultado = resultado + "to";}
                            BanderaCientos = false;
                            resultado = resultado + " " + DosDigitosCompletos[i-1]; 
                            num = false;
                        }
                        MayorQue10 = true;
                        Decenas = true;
                    }
                }
                inicio++;
                longitud--;
            }
            if(longitud == 1){
                if(MayorQue10 == true){
                    for(int i = 0; i < 10; i++){
                    if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                        if(i == 0){ resultado = resultado + ""; }
                        else{
                            if(BanderaCientos == true){ resultado = resultado + "to";}
                            BanderaCientos = false;
                            if(Decenas == true){ resultado = resultado + " y";}
                            resultado = resultado + " " + UnDigito[i-1];
                            num = false;
                        }

                    }
                }
                }else{
                    if(enteros == true){
                        for(int i = 0; i < 9; i++){
                            if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                                if(i == 0){ resultado = resultado +  ""; }
                                else{ 
                                     if(i == 1){ 
                                         Solo = true;
                                         resultado = resultado + "Un entero";
                                     }
                                     else{ resultado = resultado + UnDigito[i-1]; }
                                     num = false;
                                }
                            }
                        }
                    }else{
                        for(int i = 0; i < 9; i++){
                            if(Character.getNumericValue(numeros.charAt(inicio)) == i){
                                if(i == 0){ resultado = ""; }
                                else{ 
                                    if(denominador == false){
                                       resultado = resultado + UnDigito[i-1]; 
                                        num = false;
                                    }else{
                                        resultado = resultado + UnDigitoSolo[i-1]; 
                                        num = false;
                                    }
                                }
                            }
                        }
                    }
                }
                inicio++;
                longitud--;
            }
        }
        
        if(denominador == true && num == false && MayorQue10 == true){resultado = resultado + "avos";}
        if(enteros == true && Solo == false && resultado != "") {
            resultado = resultado + "enteros";
        }
        return resultado;
    }
 
    int ContarRepeticiones(String texto,String palabra) {
        String regex = "\\b" + Pattern.quote(palabra) + "\\b";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(texto);
        int contador = 0;
        while (matcher.find()) {
            contador++;
        }

        return contador;
    }
}
