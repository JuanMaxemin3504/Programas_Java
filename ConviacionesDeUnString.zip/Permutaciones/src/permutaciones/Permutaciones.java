/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package permutaciones;

import static GeneradorPermutaciones.GeneradorCombinaciones.GenerarPermutaciones;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author JuanMa
 */
public class Permutaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner cin;
        cin = new Scanner(System.in);
        String texto = cin.nextLine();
        char[] caracteres = texto.toCharArray();
        List<String> combinaciones = new ArrayList<>();
        GenerarPermutaciones(caracteres, 0, caracteres.length - 1, combinaciones);

        int n = 1;
        for (String combinacion : combinaciones) {
            System.out.println(String.format("%s: %s", n, combinacion));
            n++;
        }
    }
    
}
